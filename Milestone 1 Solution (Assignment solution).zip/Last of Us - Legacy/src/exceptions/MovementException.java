package exceptions;

public class MovementException extends GameActionException {

	public MovementException() {
		// TODO Auto-generated constructor stub
	}
	public MovementException(String message) {
		super(message);
	}
}
